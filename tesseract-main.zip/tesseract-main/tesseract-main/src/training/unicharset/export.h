#pragma once

#ifdef CMAKE_BUILD
#  include <unicharset_training_export.h>
#endif
